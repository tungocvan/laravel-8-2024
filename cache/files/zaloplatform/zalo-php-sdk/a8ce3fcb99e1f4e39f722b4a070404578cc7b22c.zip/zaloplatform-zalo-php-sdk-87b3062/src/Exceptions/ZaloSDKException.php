<?php
/**
 * Zalo © 2019
 *
 */

namespace Zalo\Exceptions;

/**
 * Class ZaloSDKException
 *
 * @package Zalo
 */
class ZaloSDKException extends \Exception
{
}

