<?php

return [
    'route' => env('PASSPORT_CLIENTS_URL', '/oauth-ui'),
];
