<?php

namespace Luigel\LaravelPassportViews\Http\Controllers;

class ClientController
{
    public function index()
    {
        return view('laravel-passport-views::clients');
    }
}
