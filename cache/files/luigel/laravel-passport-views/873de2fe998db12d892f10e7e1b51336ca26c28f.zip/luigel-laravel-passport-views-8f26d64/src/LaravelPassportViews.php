<?php

namespace Luigel\LaravelPassportViews;

class LaravelPassportViews
{
    // Build your next great package.
}
