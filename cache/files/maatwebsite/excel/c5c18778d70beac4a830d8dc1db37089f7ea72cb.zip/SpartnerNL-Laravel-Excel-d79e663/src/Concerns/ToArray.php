<?php

namespace Maatwebsite\Excel\Concerns;

interface ToArray
{
    /**
     * @param  array  $array
     */
    public function array(array $array);
}
